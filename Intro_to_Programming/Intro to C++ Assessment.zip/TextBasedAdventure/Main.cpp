#include "TextBasedAdventure.h"

int main()
{
	TextBasedAdventure * app = new TextBasedAdventure();
	
	app->Start();

	return 0; 
}