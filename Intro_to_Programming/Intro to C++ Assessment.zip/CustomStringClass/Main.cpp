#include "CustomStringClass.h"

int main()
{
	test1();

	system("pause");

	return 0;
}